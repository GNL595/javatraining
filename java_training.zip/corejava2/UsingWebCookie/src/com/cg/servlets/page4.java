package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/page4")
public class page4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(){

	}

	public void destroy() {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		Cookie [] cookies = request.getCookies();
		String firstName ="" , lastName="" , city="" , state="";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
			else if(cookie.getName().equals("city"))
				city=cookie.getValue();
			else if(cookie.getName().equals("state"))
				state=cookie.getValue();
		}
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body style='background-color: powderblue;'>");
		out.println("<div align=center>");
		out.println("<table><tr><td>firstName: </td> <td>"+firstName+"</td></tr>");
		out.println("<tr><td>lastName: </td><td>"+lastName+"</td></tr>");
		out.println("<tr><td>city: </td><td>"+city+"</td></tr>");
		out.println("<tr><td>state: </td><td>"+state+"</td></tr>");
		out.println("<tr><td>phone: </td><td>"+phone+"</td></tr>");
		out.println("<tr><td>email: </td><td>"+email+"</td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
