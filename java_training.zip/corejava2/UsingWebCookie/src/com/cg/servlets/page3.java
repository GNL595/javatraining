package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/page3")
public class page3 extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init()  {

	}

	public void destroy() {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		Cookie [] cookies = request.getCookies();
		String firstName ="" , lastName="";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
		}
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body style='background-color: powderblue;'>");
		out.println("<div align=center>");
		out.println("<table><tr><td>firstName: </td> <td>"+firstName+"</td></tr>");
		out.println("<tr><td>lastName: </td><td>"+lastName+"</td></tr>");
		out.println("<tr><td>city: </td><td>"+city+"</td></tr>");
		out.println("<tr><td>state: </td><td>"+state+"</td></tr>");
		out.println("<form name='page3' action='page4' method='post'>");
		out.println("<tr><td>phone: </td><td><input type='text' name='phone'></td></tr>");
		out.println("<tr><td>email: </td><td><input type='text' name='email'></td></tr>");
		out.println("<tr><td><input type='submit' value='submit'></td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		Cookie cookie1=new Cookie("city", city);
		response.addCookie(cookie1);
		Cookie cookie2=new Cookie("state", state);
		response.addCookie(cookie2);
	}

}
