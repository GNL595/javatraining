package com.cg.project.services;

import com.cg.project.Exception.InvalidNoRangeException;

public interface MathServices {
	public abstract int add(int n1,int n2)throws InvalidNoRangeException;
	public int sub(int n1,int n2)throws InvalidNoRangeException;
	float div(int n1,int n2)throws InvalidNoRangeException;
}
