package com.cg.serializable;

import java.io.File;

public class MainClass {

	public static void main(String[] args) {
		try{
		SerializableDemo re=new SerializableDemo();
		File file=new File("d:\\Iofile.txt");
		//re.doSerialization(file,new Associate(121,121, "varun"	,"jha","iit", "a","abc", "abc@gmail.com"));
		System.out.println("done deserial"+re.doDeSerialization(file)); 
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
