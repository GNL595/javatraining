package temp.main;

import java.util.ArrayList;

public class WrapperBoxing {

	public static void main(String[] args) {
		//int num=100;
		//Integer list=new Integer(num); //generaldeclaration
		//Integer list=num; //valueToObject//AutoBoxing
		//Integer list=new Integer(122);
		//int num=list.intValue();//general declaration
		//int num=list;//object ToValue //A utoUnboxing
		ArrayList list=new ArrayList();
		
		System.out.println(list);
	}

}
