package temp.main;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Iterator;

public class ListClassesDemo {
//public static void arrayListClassWork(){
	public static void main(String[] args) {
	ArrayList<String> strList=new ArrayList<>();
	strList.add("ravi");
	strList.add("ravi1");
	strList.add("ravi2");
	strList.add("ravi3");
	strList.add("ravi4");
	strList.add("ravi5");
	 Iterator<String> iterator=strList.iterator();
	 while(iterator.hasNext()){
		 String string=iterator.next();
		 System.out.println(string);
	 }
}
}
//}