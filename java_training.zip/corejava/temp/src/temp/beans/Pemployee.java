package temp.beans;
public class Pemployee extends Employee{
private int hra,ta,da;
	public Pemployee() {
		super();
	}
	public Pemployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	public Pemployee(int employeeId, int basicSalary, String firstName, String lastName, int hra, int ta, int da) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}

	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	public int calculateSalary(int basicSalary){
		int totalSalary=ta+da+hra+basicSalary;
		return totalSalary;
	}
	}
