package temp.beans;
public class OneTwo {
    private static int count;
    private int num;
	public OneTwo() {
		count++;
	}
	public OneTwo(int num) {
		super();
		this.num = num;
		while(num!=0){
			count++;
			num=num/10;
		}
		System.out.println("the number has "+count+"digits");
	}
	public static int getCount() {
		return count;
	}
	public static void setCount(int count) {
		OneTwo.count = count;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}