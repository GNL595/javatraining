import java.io.IOException;
import java.sql.SQLException;

public class Test{
	public static void main(String Args[])throws Exception{
	}
void m1() throws Exception
{
try
{
//
}
catch (IOException e)
{
throw new SQLException();
}
catch(SQLException e)
{
throw new InstantiationException();
}
finally
{
throw new CloneNotSupportedException(); // this is not a RuntimeException.
}
}
}