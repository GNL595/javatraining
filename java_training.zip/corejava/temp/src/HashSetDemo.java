import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
class HashSetDemo{ 
  public static void main(String[] args) {
     // Create a HashSet
     Set<String>  hset = new TreeSet<String>();
 
     //add elements to HashSet
     hset.add(new String("AA"));
     hset.add(new String("oo"));
     hset.add(new String("jj"));
     hset.add(new String("DD"));
 
     // Displaying HashSet elements
     System.out.println("HashSet contains: ");
     System.out.println(hset);
     }
  }
