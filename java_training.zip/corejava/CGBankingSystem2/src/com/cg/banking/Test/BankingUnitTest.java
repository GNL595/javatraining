package com.cg.banking.Test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;


public class BankingUnitTest {
	public static BankingServicesImpl services;
	
	@BeforeClass
	public static void setUpEnv(){
		services=new BankingServicesImpl();
	}

	@AfterClass
	public static void tearDownEnv(){
		services=null;
	}

	@Before
	public void setUp(){
		Customer customer=new Customer("r","r","r","r",new Address("r","r",1),new Address("r","r",1)) ;
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER);
		BankingDAOServicesImpl.customerList.put(BankingUtility.CUSTOMER_ID_COUNTER++,customer) ;
		Customer customer1=new Customer("ra","ra","ra","ra",new Address("ra","ra",1),new Address("ra","ra",1)) ;
		customer1.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER);
		BankingDAOServicesImpl.customerList.put(BankingUtility.CUSTOMER_ID_COUNTER++,customer1) ;
		
		Account account=new Account("Savings", 1000);
		account.setAccountNo(BankingUtility.ACCOUNT_NUM_GENERATOR);
		account.setStatus("Active");
		BankingDAOServicesImpl.customerList.get(customer.getCustomerId()).getAccounts().put(BankingUtility.ACCOUNT_NUM_GENERATOR++,account);
		Account account1=new Account("Savings", 1000);
		account1.setAccountNo(BankingUtility.ACCOUNT_NUM_GENERATOR);
		account1.setStatus("Active");
		BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).getAccounts().put(BankingUtility.ACCOUNT_NUM_GENERATOR++,account1);
		
		Transaction transaction=new Transaction(1000, "Deposit");
		transaction.setTransactionId(BankingUtility.TRANSACTION_NUM_GENERATOR);
		BankingDAOServicesImpl.customerList.get(customer.getCustomerId()).getAccounts().get(account.getAccountNo()).getTransactions().put(BankingUtility.TRANSACTION_NUM_GENERATOR++,transaction);
		Transaction transaction1=new Transaction(1000, "Withdraw");
		transaction1.setTransactionId(BankingUtility.TRANSACTION_NUM_GENERATOR);
		BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).getTransactions().put(BankingUtility.TRANSACTION_NUM_GENERATOR++,transaction);
		
		BankingDAOServicesImpl.customerList.get(customer.getCustomerId()).getAccounts().get(account.getAccountNo()).setPinNumber(1111);
		BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).setPinNumber(1111);
		
	}

	@After
	public void tearDown(){
		BankingDAOServicesImpl.customerList.clear();
		BankingUtility.CUSTOMER_ID_COUNTER=1000;
		BankingUtility.ACCOUNT_NUM_GENERATOR=10000000;
		BankingUtility.TRANSACTION_NUM_GENERATOR=1000;
	}

	@Test
	public void ValidInsertCustomer() throws BankingServicesDownException{
	int actual=	services.acceptCustomerDetails("a", "a", "a", "a", "a", "a", 1, "a", "a", 1);
	Assert.assertEquals(1002, actual);
	}
	@Test
	public void validInsertAccount() throws CustomerNotFoundException,BankingServicesDownException,InvalidAccountTypeException,InvalidAmountException{
	long  actual=  services.openAccount(1000, "savings",1000);
	Assert.assertEquals(10000002, actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void invalidInsertAccount() throws CustomerNotFoundException,BankingServicesDownException,InvalidAccountTypeException,InvalidAmountException{
		services.openAccount(1100, "savings",1000);
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void invalidInsertAccountType() throws CustomerNotFoundException,BankingServicesDownException,InvalidAccountTypeException,InvalidAmountException{
		services.openAccount(1000, "savin",1000);
	}
	@Test(expected=InvalidAmountException.class)
	public void invalidInsertAccountAmount() throws CustomerNotFoundException,BankingServicesDownException,InvalidAccountTypeException,InvalidAmountException{
		services.openAccount(1000, "savings",0);
	}
	@Test
	public void validDepositAmount() throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		int i= (int)services.depositAmount(1000, 10000000, 1000);
		Assert.assertEquals(2000, i);
	}
	@Test(expected=CustomerNotFoundException.class )
	public void invalidCustomerDepositAmount() throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		services.depositAmount(1002, 10000000, 1000);
	}
	@Test(expected=AccountNotFoundException.class )
	public void invalidAccountDepositAmount() throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		services.depositAmount(1000, 10000001, 1000);
	}
	@Test(expected=InvalidAmountException.class )
	public void invalidDepositAmount() throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		services.depositAmount(1000, 10000000, -1000);
	}
	@Test(expected=AccountBlockedException.class )
	public void invalidDepositAmountAccountType() throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(10000000l).setStatus("Blocked");
		services.depositAmount(1000, 10000000, 1000);
	}
	@Test
	public void validWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		int bal=(int)services.withdrawAmount(1000, 10000000, 100, 1111);
		Assert.assertEquals(900, bal);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void invalidCustomerInvalidWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		services.withdrawAmount(10100, 10000000, 100, 1111);
	}
	@Test(expected=AccountNotFoundException.class)
	public void invalidAccountInvalidWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		services.withdrawAmount(1000, 100010000, 100, 1111);
	}
	@Test(expected=InsufficientAmountException.class)
	public void invalidAmmountInvalidWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		services.withdrawAmount(1000, 10000000, 10000, 1111);
	}
	@Test(expected=InvalidAmountException.class)
	public void invalidDrawAmmountInvalidWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		services.withdrawAmount(1000, 10000000, -10000, 1111);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void invalidPinInvalidWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		services.withdrawAmount(1000, 10000000, 100, 11110);
	}
	@Test(expected=AccountBlockedException.class)
	public void invalidAccountStatusWithdraw()throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException{
		BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(10000000l).setStatus("Blocked");
		services.withdrawAmount(1000, 10000000, 100, 1111);
	}
	@Test
	public void validFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		Assert.assertTrue(services.fundTransfer(1001, 10000001, 1000, 10000000, 100, 1111));
	}
	@Test(expected=InsufficientAmountException.class)
	public void InvalidAmountInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 10000001, 1000, 10000000, 10000, 1111);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void InvalidCustomerToInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1011, 10000001, 1000, 10000000, 10000, 1111);
	}
	@Test(expected=AccountNotFoundException.class)
	public void InvalidAccountToInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 100000011, 1000, 10000000, 10000, 1111);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void InvalidCustomerFromInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 10000001, 1010, 10000000, 10000, 1111);
	}
	@Test(expected=AccountNotFoundException.class)
	public void InvalidAccountFromToInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 10000001, 1000, 100000100, 10000, 1111);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void InvalidPinToInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 10000001, 1000, 10000000, 10000, 1101);
	}
	@Test(expected= AccountBlockedException.class)
	public void InvalidFromAccountBlockedInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(10000000l).setStatus("Blocked");
		services.fundTransfer(1001, 10000001, 1000, 10000000, 10000, 1101);
	}
	@Test(expected= AccountBlockedException.class)
	public void InvalidToAccountBlockedInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		BankingDAOServicesImpl.customerList.get(1001).getAccounts().get(10000001l).setStatus("Blocked");
		services.fundTransfer(1001, 10000001, 1000, 10000000, 10000, 1101);
	}
	@Test(expected= InvalidAmountException.class)
	public void InvalidAmountTransferInvalidFundTransfer()throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		services.fundTransfer(1001, 10000001, 1000, 10000000, -10000, 1101);
	}
	@Test
	public void validChangePin()throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException{
		Assert.assertTrue(services.changeAccountPin(1000, 10000000, 1111, 2222));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void inavlidCusrtomerInvalidChangePin()throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException{
		services.changeAccountPin(1100, 10000000, 1111, 2222);
	}
	@Test(expected=AccountNotFoundException.class)
	public void inavlidAccountInvalidChangePin()throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException{
		services.changeAccountPin(1000, 11000000, 1111, 2222);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void inavlidPinInvalidChangePin()throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException{
		services.changeAccountPin(1000, 10000000, 1191, 2222);
	}
	
}
