package com.cg.mobilebilling.main;
public class MainClass {
	public static void main(String[] args) {
		
	}
}
