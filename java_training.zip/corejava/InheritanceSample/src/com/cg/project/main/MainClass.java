package com.cg.project.main;

import com.cg.project.beans.CEmployee;
import com.cg.project.beans.DEmployee;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;
import com.cg.project.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		/*PEmployee employee=new PEmployee(5444, 2241, "ravi", "teja");
		employee.calculateSalary();
		System.out.println(employee.toString());
		CEmployee cemployee=new CEmployee(4435, "ravi", "varma", 490);
		cemployee.calculateSalary();
		System.out.println(cemployee.toString());
		DEmployee demployee=new DEmployee(5536, 2345, "chetan", "namala", 2, 5000);
		demployee.calculateSalary();
		System.out.println(demployee.toString());
		SalesManager saler=new SalesManager(5555, 40000, "manoj", "kumar", 40000);
		saler.calculateSalary();
		System.out.println(saler.toString());*/
		Employee emp;
		emp=new PEmployee(555, 10000, "ravio", "mario");
		PEmployee emp1=(PEmployee)emp;
		emp.calculateSalary();
		System.out.println(emp.toString());
		emp1.calculateSalary();
		System.out.println(emp1.toString());
	}
}
