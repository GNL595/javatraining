package com.cg.project.beans;

public class PEmployee extends Employee{
	private double hra,ta,da;
	public PEmployee() {
		super();
	}

	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName, double hra, double ta, double da) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hra=hra;
		this.ta=ta;
		this.da=da;
	}

	public double getHra() {
		return hra;
	}

	public void setHra(double hra) {
		this.hra = hra;
	}

	public double getTa() {
		return ta;
	}

	public void setTa(double ta) {
		this.ta = ta;
	}

	public double getDa() {
		return da;
	}

	public void setDa(double da) {
		this.da = da;
	}
	public void calculateSalary(){
		this.hra=this.getBasicSalary()*0.2;
		this.ta=this.getBasicSalary()*0.4;
		this.da=this.getBasicSalary()*0.3;
		this.setTotalSal(this.getBasicSalary()+hra+ta+da);
	}

	@Override
	public String toString() {
		return super.toString() +"PEmployee [hra=" + hra + ", ta=" + ta + ", da=" + da + "]";
	}
	
		
}
	