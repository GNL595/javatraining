package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices{

	@Override
	public String sayHello(String name) {
		return "Hello"+" "+name;
	}

	@Override
	public String sayGoodBye(String name) {
		return "GoodBye"+" "+name;
	}
	

}
