package Com.CG.HousingDotCom.Beans;

public class Loan {
	private String loanAvailability;
	private int principleAmountFirstPaid,interestCharge,duration;
	public Loan() {}
	public Loan(String loanAvailability, int principleAmountFirstPaid, int interestCharge, int duration) {
		super();
		this.loanAvailability = loanAvailability;
		this.principleAmountFirstPaid = principleAmountFirstPaid;
		this.interestCharge = interestCharge;
		this.duration = duration;
	}
	public String getLoanAvailability() {
		return loanAvailability;
	}
	public void setLoanAvailability(String loanAvailability) {
		this.loanAvailability = loanAvailability;
	}
	public int getPrincipleAmountFirstPaid() {
		return principleAmountFirstPaid;
	}
	public void setPrincipleAmountFirstPaid(int principleAmountFirstPaid) {
		this.principleAmountFirstPaid = principleAmountFirstPaid;
	}
	public int getInterestCharge() {
		return interestCharge;
	}
	public void setInterestCharge(int interestCharge) {
		this.interestCharge = interestCharge;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	

}
