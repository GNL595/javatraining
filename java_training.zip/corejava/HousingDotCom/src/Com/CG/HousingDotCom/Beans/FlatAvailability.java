package Com.CG.HousingDotCom.Beans;

public class FlatAvailability {
	private int flatNo,flatCost;
	private String measurement,typeOfSelling,flatBuySale;
	public FlatAvailability() {}
	public FlatAvailability(int flatNo, int flatCost, String measurement, String typeOfSelling, String flatBuySale) {
		super();
		this.flatNo = flatNo;
		this.flatCost = flatCost;
		this.measurement = measurement;
		this.typeOfSelling = typeOfSelling;
		this.flatBuySale = flatBuySale;
	}
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public int getFlatCost() {
		return flatCost;
	}
	public void setFlatCost(int flatCost) {
		this.flatCost = flatCost;
	}
	public String getMeasurement() {
		return measurement;
	}
	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}
	public String getTypeOfSelling() {
		return typeOfSelling;
	}
	public void setTypeOfSelling(String typeOfSelling) {
		this.typeOfSelling = typeOfSelling;
	}
	public String getFlatBuySale() {
		return flatBuySale;
	}
	public void setFlatBuySale(String flatBuySale) {
		this.flatBuySale = flatBuySale;
	}
	
}
