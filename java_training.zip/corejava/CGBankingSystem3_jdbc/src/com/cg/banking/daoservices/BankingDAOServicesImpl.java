package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices {
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private org.hibernate.Transaction tx;
    public BankingDAOServicesImpl() {
	}
	@Override
	public int insertCustomer(Customer customer) {
		try{
		session=sessionFactory.openSession();
		tx= session.beginTransaction();
		int custId=(int) session.save(customer);
		tx.commit();
		return custId;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Customer customer=(Customer) session.get(Customer.class, customerId);
			account.setCustomer(customer);
			account.setStatus("active");
			long accNo= (long) session.save(account);
			tx.commit();
			return accNo;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		try{
			tx= session.beginTransaction();
			if(account.getCustomer().getCustomerId()==customerId){
			session.update(account);
			tx.commit();
			session.flush();
			return true;
			}
			return false;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}

	@Override
	public int generatePin(int customerId, Account account) {
		account.setPinNumber(BankingUtility.rand.nextInt(9999));
		updateAccount(customerId, account);
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Account account=(Account) session.get(Account.class, accountNo);
			transaction.setAccount(account);
			session.save(transaction);
			tx.commit();
			return true;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Customer customer=(Customer) session.get(Customer.class, customerId);
			session.delete(customer);
			tx.commit();
			return true;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
		}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Account account=(Account) session.get(Account.class, accountNo);
			if(account.getCustomer().getCustomerId()==customerId){
			session.delete(account);
			tx.commit();
			return true;
			}
			return false;
			}
			catch(HibernateException e){
				e.printStackTrace();
				tx.rollback();
				throw e;
			}
			finally{
				session.close();
			}
		}

	@Override
	public Customer getCustomer(int customerId) { 
		session=sessionFactory.openSession();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Account account=(Account) session.get(Account.class, accountNo);
		if(account.getCustomer().getCustomerId()==customerId){
		return account;
		}
    	else
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Customer a");
		return query.list();
	}

	@Override
	public ArrayList<Account> getAccounts(int customerId) {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Account a where customer_customerId= :customerId");
		query.setParameter("customerId", customerId);
		return (ArrayList<Account>) query.list();
	}

	@Override
	public ArrayList<Transaction> getTransactions(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Transaction a where account_accountNo= :accountNo");
		query.setParameter("accountNo", accountNo);
		return (ArrayList<Transaction>) query.list();
	}
}