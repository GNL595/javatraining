package com.cg.banking.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Address;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	BankingDAOServicesImpl bankingDAOServices;
	
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return bankingDAOServices.insertCustomer(new Customer(firstName,lastName,customerEmailId,panCard,new Address(localAddressCity,localAddressState,localAddressPinCode),new Address(homeAddressCity,homeAddressState,homeAddressPinCode)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")){
			if(initBalance<500)
				throw new InvalidAmountException("The given amount for initial balance is inavlid. Please input vaild initial balance");
			return bankingDAOServices.insertAccount(customerId, new Account(accountType,initBalance));
		}
		throw new InvalidAccountTypeException("The given Account type is not supported");
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServices.getAccount(customerId, accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid amount for transaction");
		if((bankingDAOServices.getAccount(customerId, accountNo).getStatus()).equalsIgnoreCase("Active")){
			Account account=bankingDAOServices.getAccount(customerId, accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			bankingDAOServices.updateAccount(customerId, account);
			bankingDAOServices.insertTransaction(customerId, accountNo, new Transaction(amount,"Deposit"));
			return bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();
		}
		else 
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServices.getAccount(customerId, accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid amount for transaction");
		if(bankingDAOServices.getAccount(customerId, accountNo).getPinCounter()==3)
			throw new AccountBlockedException("Your Account is blocked do to wrong entry of pin greater than 3times");
		if(bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()==pinNumber)
			if(bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance()-amount>0){
				Account account=bankingDAOServices.getAccount(customerId, accountNo);
				account.setPinCounter(0);
				account.setAccountBalance(account.getAccountBalance()-amount);
				bankingDAOServices.updateAccount(customerId, account);
				bankingDAOServices.insertTransaction(customerId, accountNo, new Transaction(amount,"Withdrawl"));
				return bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();
			}
			else{
				throw new InsufficientAmountException("Insufficient balance for this transaction");
			}
		else {
			Account account=bankingDAOServices.getAccount(customerId, accountNo);
			account.setPinCounter(account.getPinCounter()+1);
			bankingDAOServices.updateAccount(customerId, account);
			if(bankingDAOServices.getAccount(customerId, accountNo).getPinCounter()==3){
				account.setStatus("Blocked");
				bankingDAOServices.updateAccount(customerId, account);
			}
			throw new InvalidPinNumberException("Enter Correct Pin");
		}
	}
	
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(bankingDAOServices.getCustomer(customerIdTo)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerIdTo+" not Found");
		if(bankingDAOServices.getAccount(customerIdTo, accountNoTo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNoTo+" not Found");
		if((bankingDAOServices.getAccount(customerIdTo, accountNoTo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Reciever Account is Blocked");
		withdrawAmount(customerIdFrom, accountNoFrom,transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo,transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		return	bankingDAOServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return bankingDAOServices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return  bankingDAOServices.generatePin(customerId, bankingDAOServices.getAccount(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if(oldPinNumber==bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()) {
			Account account =bankingDAOServices.getAccount(customerId, accountNo);
			account.setPinNumber(newPinNumber);
			bankingDAOServices.updateAccount(customerId, account);
			return true;
		}
		else throw new InvalidPinNumberException("Invalid old pin\n Enter Correct pin to change the pin");
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingDAOServices.getCustomers();
	}

	@Override
	public ArrayList<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		return bankingDAOServices.getAccounts(customerId);
	}

	@Override
	public ArrayList<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return bankingDAOServices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServices.getAccount(customerId, accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		return bankingDAOServices.getAccount(customerId, accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return bankingDAOServices.deleteAccount(customerId, accountNo);
	}

	public boolean removeCustomer(int customerId) throws BankingServicesDownException, CustomerNotFoundException{
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		return bankingDAOServices.deleteCustomer(customerId);
	}
}
