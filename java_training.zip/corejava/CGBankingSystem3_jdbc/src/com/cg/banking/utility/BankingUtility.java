package com.cg.banking.utility;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import com.cg.banking.exceptions.BankingServicesDownException;
public class BankingUtility {
	public static Random rand= new Random();
	public static int CUSTOMER_ID_COUNTER=1000;
	public static long ACCOUNT_NUM_GENERATOR=10000000;
	public static int TRANSACTION_NUM_GENERATOR=1000;
	private static Connection conn=null;
	public static Connection getDBConnection()  throws BankingServicesDownException{
		try{if(conn==null){
			Properties properties=new Properties();
			properties.load(new FileInputStream(new File(".//resource//banking.properities")));
			Class.forName(properties.getProperty("driver"));
			conn=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("user"), properties.getProperty("password"));
			System.out.println("hi");
		}
		return conn;
		}
		catch(ClassNotFoundException | IOException | SQLException e){
			e.printStackTrace();
			throw new BankingServicesDownException("Payroll services are down please try again later",e);
		}
	}
}
