package com.cg.payroll.utility;

import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.InvalidDataException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class Mainclass {
	public static void main(String args[]) throws PayrollServicesDownException, InvalidDataException{
	try{
			PayrollServices p= new PayrollServicesImpl();
		/*	System.out.println(p.acceptAssociate(100, "r", "a", "v", "i", "t", "e", 10000,100,100,100, "g", "nl"));
			System.out.println(p.acceptAssociate(150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978"));
			System.out.println(p.acceptAssociate(20000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978"));
			System.out.println(p.acceptAssociate(20000, "Ravi1", "teja1", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978"));*/
		System.out.println(p.getAllAssociateDetails());
	}
	catch(PayrollServicesDownException e){
		e.printStackTrace();
		System.out.println(e);
	}
	catch(Exception e){
		e.printStackTrace();
	}
	}
}
