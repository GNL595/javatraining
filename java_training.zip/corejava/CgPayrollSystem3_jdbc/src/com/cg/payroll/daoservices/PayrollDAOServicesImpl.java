package com.cg.payroll.daoservices;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.AssociateMapper;


@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private JdbcTemplate JdbcTemplate;
	public PayrollDAOServicesImpl() throws PayrollServicesDownException {
	}
	@Override
	public int insertAssociate(Associate associate) throws  SQLException{
		String sql="insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)";
		JdbcTemplate.update(sql, associate.getYearlyInvestmentUnder80C(), associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId());
		String sql1="select max(associateId) from associate";
		List<Associate> a=JdbcTemplate.query(sql1, new AssociateMapper());
		int b=a.get(0).getAssociateId();
		
		String sql2="insert into bankdetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?) ";
		JdbcTemplate.update(sql2,b,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode());
		
		String sql3="insert into salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)";
		JdbcTemplate.update(sql3,b,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf());
		return b;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		String sql="update associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateId=?";
		JdbcTemplate.update(sql, associate.getYearlyInvestmentUnder80C(), associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId(),associate.getAssociateId());
		String sql2="update bankdetails set accountNumber=?,bankName=?,ifscCode=? where associateId=?";
		JdbcTemplate.update(sql2,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode(),associate.getAssociateId());
		String sql3="update salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,netSalary=? where associateId=?";
		JdbcTemplate.update(sql3,associate.getSalary().getBasicSalary(),associate.getSalary().getHra(),associate.getSalary().getConveyenceAllowance(),associate.getSalary().getOtherAllowance(),associate.getSalary().getPersonalAllowance(),associate.getSalary().getMonthlyTax(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf(),associate.getSalary().getGratuity(),associate.getSalary().getGrossSalary(),associate.getSalary().getNetSalary(),associate.getAssociateId());
	 return true;
		}

	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		String sql="delete from associate where associateId=?";
		JdbcTemplate.update(sql,associateId);
	return true;
	}

	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		String sql="select a.associateId,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n"+
				"b.accountNumber,b.bankName,b.ifscCode,\r\n"+
				 "c.basicSalary,c.hra,c.conveyenceAllowance,c.otherAllowance,c.personalAllowance,c.monthlyTax,c.epf,c.companyPf,c.gratuity,c.grossSalary,c.netSalary\r\n"+
				"from associate a inner join bankdetails b inner join salary c\r\n"+
					"on a.associateId=b.associateId and a.associateId=c.associateId\r\n"+
						"where a.associateId=?";
		Object [] obj={associateId};
		Associate a= JdbcTemplate.queryForObject(sql, obj, new AssociateMapper());
		System.out.println(a);
		return a;
	}
	@Override
	public List<Associate> getAssociate() throws SQLException {
		String sql="select a.associateId,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n"+
				"b.accountNumber,b.bankName,b.ifscCode,\r\n"+
				 "c.basicSalary,c.hra,c.conveyenceAllowance,c.otherAllowance,c.personalAllowance,c.monthlyTax,c.epf,c.companyPf,c.gratuity,c.grossSalary,c.netSalary\r\n"+
				"from associate a inner join bankdetails b inner join salary c\r\n"+
					"on a.associateId=b.associateId and a.associateId=c.associateId\r\n";
		List<Associate> associates= JdbcTemplate.queryForList(sql, Associate.class);
		return associates;
	}
}