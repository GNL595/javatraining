package com.cg.project.main;

import com.cg.project.threadwork.Customer;

public class MainClass {

	public static void main(String[] args) {
		Thread th1 = new Thread(new Customer(),"ravi");
		Thread th2 = new Thread(new Customer(),"teja");
		Thread th3 = new Thread(new Customer(),"gnl");
		th1.start();
		th2.start();
		th3.start();
	}

}
