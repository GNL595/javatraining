package com.cg.onllinecabbooking.beans;

public class Customer {
	private int mobileNo;
	private String name,emailId;
	public Customer(int mobileNo, String name, String emailId) {
		super();
		this.mobileNo = mobileNo;
		this.name = name;
		this.emailId = emailId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
