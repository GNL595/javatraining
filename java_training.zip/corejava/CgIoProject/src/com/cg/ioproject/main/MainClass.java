package com.cg.ioproject.main;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		try{
			File file =new File("d:\\Iofile.txt");
			File file1=new File("d:\\outfile.txt");
			if(!file.exists())
				file.createNewFile();
			if(!file1.exists())
				file1.createNewFile();
			System.out.println(file.length());
			System.out.println(file.canRead());
			System.out.println(file.canWrite());
			System.out.println(file. getParentFile());
			CopyFileStram.copyingFile(file, file1);
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}

}
