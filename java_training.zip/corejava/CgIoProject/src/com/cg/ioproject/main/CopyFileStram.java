package com.cg.ioproject.main;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyFileStram {
	public static void copyingFile(File fromFile,File toFile)throws IOException{
		try(BufferedInputStream src=new BufferedInputStream(new FileInputStream(fromFile))){
			try(BufferedOutputStream dest=new BufferedOutputStream(new FileOutputStream(toFile))){
				int a=0;
				while((a=src.read())!=-1){
						dest.write(a);
				}
			}
		}
		}
}
		/*public static void copyingFile(File fromFile,File toFile)throws IOException{
			FileInputStream src=new FileInputStream(fromFile);
			FileOutputStream dest=new FileOutputStream(toFile);
			/*1st Method*/
			//int a=0;
			//while((a=src.read())!=-1){
			//	dest.write(a);
			//	}
			/*2nd Method*/
			/*byte [] Dbuffer=new byte[(int)fromFile.length()];
			src.read(Dbuffer);
			dest.write(Dbuffer);
			src.close();
			dest.close();
			
		}
}*/