package com.cg.airreservation.beans;
public class CancelTicket {
	public CancelTicket() {}
	private String CancellationPolicy,LastDateForCancellation;
	private float CancellationCharges,refundAmount;
	private TransactionDetails transactiondetails;
	public CancelTicket(String cancellationPolicy, String lastDateForCancellation, float cancellationCharges,
			float refundAmount, TransactionDetails transactiondetails) {
		super();
		CancellationPolicy = cancellationPolicy;
		LastDateForCancellation = lastDateForCancellation;
		CancellationCharges = cancellationCharges;
		this.refundAmount = refundAmount;
		this.transactiondetails = transactiondetails;
	}
	public String getCancellationPolicy() {
		return CancellationPolicy;
	}
	public void setCancellationPolicy(String cancellationPolicy) {
		CancellationPolicy = cancellationPolicy;
	}
	public String getLastDateForCancellation() {
		return LastDateForCancellation;
	}
	public void setLastDateForCancellation(String lastDateForCancellation) {
		LastDateForCancellation = lastDateForCancellation;
	}
	public float getCancellationCharges() {
		return CancellationCharges;
	}
	public void setCancellationCharges(float cancellationCharges) {
		CancellationCharges = cancellationCharges;
	}
	public float getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(float refundAmount) {
		this.refundAmount = refundAmount;
	}
	public TransactionDetails getTransactiondetails() {
		return transactiondetails;
	}
	public void setTransactiondetails(TransactionDetails transactiondetails) {
		this.transactiondetails = transactiondetails;
	}
}