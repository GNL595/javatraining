package com.cg.airreservation.beans;
public class Ticket {
	private int ticketId;
	private TicketDetails ticketDetails;
	private CancelTicket cancelticket;
	public Ticket() {}
	public Ticket(int ticketId, TicketDetails ticketDetails, CancelTicket cancelticket) {
		super();
		this.ticketId = ticketId;
		this.ticketDetails = ticketDetails;
		this.cancelticket = cancelticket;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public TicketDetails getTicketDetails() {
		return ticketDetails;
	}
	public void setTicketDetails(TicketDetails ticketDetails) {
		this.ticketDetails = ticketDetails;
	}
	public CancelTicket getCancelticket() {
		return cancelticket;
	}
	public void setCancelticket(CancelTicket cancelticket) {
		this.cancelticket = cancelticket;
	}
}