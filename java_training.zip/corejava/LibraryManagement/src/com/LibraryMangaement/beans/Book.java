package com.LibraryMangaement.beans;

public class Book {
		private String typeOfBook,bookID,bookName,bookAvailability;
		private int totNoOfBooks,noOfBooksAvailable,noOfBooksIssued;
			
			public Book(String typeOfBook, String bookID, String bookName,
					String bookAvailability, int totNoOfBooks,
					int noOfBooksAvailable, int noOfBooksIssued) {
				super();
				this.typeOfBook = typeOfBook;
				this.bookID = bookID;
				this.bookName = bookName;
				this.bookAvailability = bookAvailability;
				this.totNoOfBooks = totNoOfBooks;
				this.noOfBooksAvailable = noOfBooksAvailable;
				this.noOfBooksIssued = noOfBooksIssued;
			}
			public String getTypeOfBook() {
				return typeOfBook;
			}
			public void setTypeOfBook(String typeOfBook) {
				this.typeOfBook = typeOfBook;
			}
			public String getBookID() {
				return bookID;
			}
			public void setBookID(String bookID) {
				this.bookID = bookID;
			}
			public String getBookName() {
				return bookName;
			}
			public void setBookName(String bookName) {
				this.bookName = bookName;
			}
			public String getBookAvailability() {
				return bookAvailability;
			}
			public void setBookAvailability(String bookAvailability) {
				this.bookAvailability = bookAvailability;
			}
			public int getTotNoOfBooks() {
				return totNoOfBooks;
			}
			public void setTotNoOfBooks(int totNoOfBooks) {
				this.totNoOfBooks = totNoOfBooks;
			}
			public int getNoOfBooksAvailable() {
				return noOfBooksAvailable;
			}
			public void setNoOfBooksAvailable(int noOfBooksAvailable) {
				this.noOfBooksAvailable = noOfBooksAvailable;
			}
			public int getNoOfBooksIssued() {
				return noOfBooksIssued;
			}
			public void setNoOfBooksIssued(int noOfBooksIssued) {
				this.noOfBooksIssued = noOfBooksIssued;
			}
			
}
