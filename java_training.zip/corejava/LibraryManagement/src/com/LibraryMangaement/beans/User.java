package com.LibraryMangaement.beans;

public class User {
		private String name,userID;
		private long mobileNo;
		
		public User(String name, String userID, long mobileNo) {
			super();
			this.name = name;
			this.userID = userID;
			this.mobileNo = mobileNo;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getUserID() {
			return userID;
		}
		public void setUserID(String userID) {
			this.userID = userID;
		}
		public long getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}
		
}
