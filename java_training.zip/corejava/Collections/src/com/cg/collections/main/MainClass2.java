package com.cg.collections.main;

import com.cg.collections.MyGenericType;
import java.util.ArrayList;
import java.util.List;
public class MainClass2 {

	public static void main(String[] args) {
		//MyGenericType<String> strobj=new MyGenericType<>("r","t");
		ArrayList<String> stringList=new ArrayList<>();
		stringList.add("ravi");
		stringList.add("ravi1");	
		stringList.add("ravi2");
		
		ArrayList<Integer> intList=new ArrayList<>();
		intList.add(1);
		intList.add(2);
		intList.add(3);
		//printl(strobj);
		printl(stringList);
		printl(intList);
		
	}
		public static void printl(List<?> element){
			for(Object object : element)
				System.out.println(object);
		}
	}

