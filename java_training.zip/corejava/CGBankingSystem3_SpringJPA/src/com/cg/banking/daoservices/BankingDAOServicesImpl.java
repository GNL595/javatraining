package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices {
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
    public BankingDAOServicesImpl() {
	}
	@Override
	public int insertCustomer(Customer customer) {
		entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
			Customer customer=(Customer) entityManager.find(Customer.class, customerId);
			customer.setAccounts(null);
			account.setCustomer(customer);
			account.setStatus("active");
			entityManager.persist(account);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
			entityManager.getTransaction().begin(); 
			if(account.getCustomer().getCustomerId()==customerId){
			entityManager.merge(account);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
			}
			return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		account.setPinNumber(BankingUtility.rand.nextInt(9999));
		updateAccount(customerId, account);
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account=(Account) entityManager.find(Account.class, accountNo);
			transaction.setAccount(account);
			entityManager.persist(transaction);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
			entityManager=entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Customer customer=(Customer) entityManager.find(Customer.class, customerId);
			entityManager.remove(customer);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
		}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
			entityManager=entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Account account=(Account) entityManager.find(Account.class, accountNo);
			if(account.getCustomer().getCustomerId()==customerId){
			entityManager.remove(account);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
			}
			return false;
		}

	@Override
	public Customer getCustomer(int customerId) { 
		entityManager=entityManagerFactory.createEntityManager();
		Customer customer=(Customer) entityManager.find(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		entityManager=entityManagerFactory.createEntityManager();
		Account account=(Account) entityManager.find(Account.class, accountNo);
		if(account.getCustomer().getCustomerId()==customerId){
		return account;
		}
    	else
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Customer a");
		return query.getResultList();
	}

	@Override
	public ArrayList<Account> getAccounts(int customerId) {
		entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Account a where customer_customerId= :customerId");
		query.setParameter("customerId", customerId);
		return (ArrayList<Account>) query.getResultList();
	}

	@Override
	public ArrayList<Transaction> getTransactions(int customerId, long accountNo) {
		entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Transaction a where account_accountNo= :accountNo");
		query.setParameter("accountNo", accountNo);
		return (ArrayList<Transaction>) query.getResultList();
	}
}