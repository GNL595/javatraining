package com.cg.payroll.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.InvalidDataException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices = (PayrollServices)applicationContext.getBean("payrollServices");
		try {
			System.out.println( payrollServices.acceptAssociate(150000, "hero", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978"));
			payrollServices.calculateNetSalary(1);
			payrollServices.acceptAssociate(150000, "hero", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978");
			payrollServices.acceptAssociate(50000, "hero", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 10000, 1000,1000,13567899, "HDFC", "HD00978");
			payrollServices.calculateNetSalary(2);
			payrollServices.doDeleteAssociate(2);
			payrollServices.calculateNetSalary(3);
			payrollServices.getAssociateDetails(3);
			System.out.println(payrollServices.getAllAssociateDetails());
			
		} catch (PayrollServicesDownException e) {
			e.printStackTrace();
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		} catch (InvalidDataException e) {
			e.printStackTrace();
		}
	}
	}
		//payrollServices.acceptAssociate(150000, "hero", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978");
/*        int associateId1=payrollServices.acceptAssociate(150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978");
		int associateId2=payrollServices.acceptAssociate(20000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978");
		int associateId3=payrollServices.acceptAssociate(20000, "Ravi1", "teja1", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978");
		System.out.println(payrollServices.doUpdateAssociate(113,20000, "Ravi10", "teja10", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978"));
		System.out.println(payrollServices.getAssociateDetails(113).getFirstName());
		System.out.println(payrollServices.doDeleteAssociate(associateId3));
		System.out.println(payrollServices.calculateNetSalary(associateId1)+ " "+payrollServices.getAssociateDetails(associateId1).getSalary().getGratuity()+" "+payrollServices.getAssociateDetails(associateId1).getSalary().getMonthlyTax());
		System.out.println(payrollServices.calculateNetSalary(associateId2)+ " "+payrollServices.getAssociateDetails(associateId2).getSalary().getGratuity()+" "+payrollServices.getAssociateDetails(associateId2).getSalary().getMonthlyTax());
		System.out.println(payrollServices.getAssociateDetails(130).getSalary().getPersonalAllowance());
		}
		catch(AssociateDetailsNotFoundException e){
			e.printStackTrace();
			}
		catch(InvalidDataException e){
				e.printStackTrace();
		}
	}*/