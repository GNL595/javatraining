package com.cg.leavemanagemetystem.beans;

public class TypeOfLeave {
	private String leaveType;
	private int totNoOfLeaves,leavestaken,leavesRemained;
	public TypeOfLeave(String leaveType, int totNoOfLeaves, int leavestaken,
			int leavesRemained) {
		super();
		this.leaveType = leaveType;
		this.totNoOfLeaves = totNoOfLeaves;
		this.leavestaken = leavestaken;
		this.leavesRemained = leavesRemained;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public int getTotNoOfLeaves() {
		return totNoOfLeaves;
	}
	public void setTotNoOfLeaves(int totNoOfLeaves) {
		this.totNoOfLeaves = totNoOfLeaves;
	}
	public int getLeavestaken() {
		return leavestaken;
	}
	public void setLeavestaken(int leavestaken) {
		this.leavestaken = leavestaken;
	}
	public int getLeavesRemained() {
		return leavesRemained;
	}
	public void setLeavesRemained(int leavesRemained) {
		this.leavesRemained = leavesRemained;
	}

}
