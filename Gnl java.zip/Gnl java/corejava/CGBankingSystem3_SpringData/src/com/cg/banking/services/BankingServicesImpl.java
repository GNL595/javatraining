package com.cg.banking.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesAccount;
import com.cg.banking.daoservices.BankingDAOServicesCustomer;
import com.cg.banking.daoservices.BankingDAOServicesTransaction;
import com.cg.banking.beans.Address;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.utility.BankingUtility;
@Component("bankServices")
@Transactional(propagation = Propagation.REQUIRES_NEW )
public class BankingServicesImpl implements BankingServices {
	@Autowired
	BankingDAOServicesCustomer bankingDAOServicesCustomer;
	@Autowired
	BankingDAOServicesAccount bankingDAOServicesAccount;
	@Autowired
	BankingDAOServicesTransaction bankingDAOServicesTransaction;
	
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		Customer customer=bankingDAOServicesCustomer.save(new Customer(firstName,lastName,customerEmailId,panCard,new Address(localAddressCity,localAddressState,localAddressPinCode),new Address(homeAddressCity,homeAddressState,homeAddressPinCode)));
		return customer.getCustomerId();
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")){
			if(initBalance<500)
				throw new InvalidAmountException("The given amount for initial balance is inavlid. Please input vaild initial balance");
			Customer customer=bankingDAOServicesCustomer.findOne(customerId);
			Account account=new Account(accountType,initBalance);
			account.setCustomer(customer);
			account.setStatus("Active");
			return bankingDAOServicesAccount.save( account).getAccountNo();
		}
		throw new InvalidAccountTypeException("The given Account type is not supported");
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServicesAccount.findOne(accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid amount for transaction");
		if((bankingDAOServicesAccount.findOne(accountNo).getStatus()).equalsIgnoreCase("Active")){
			Account account=bankingDAOServicesAccount.findOne(accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			bankingDAOServicesAccount.saveAndFlush(account);
			Transaction transaction=new Transaction(amount,"Deposit");
			transaction.setAccount(account);
			bankingDAOServicesTransaction.save(transaction);
			return bankingDAOServicesAccount.findOne(accountNo).getAccountBalance();
		}
		else 
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServicesAccount.findOne(accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid amount for transaction");
		if(bankingDAOServicesAccount.findOne(accountNo).getPinCounter()==3)
			throw new AccountBlockedException("Your Account is blocked do to wrong entry of pin greater than 3times");
		if(bankingDAOServicesAccount.findOne(accountNo).getPinNumber()==pinNumber)
			if(bankingDAOServicesAccount.findOne(accountNo).getAccountBalance()-amount>0){
				Account account=bankingDAOServicesAccount.findOne(accountNo);
				account.setPinCounter(0);
				account.setAccountBalance(account.getAccountBalance()-amount);
				bankingDAOServicesAccount.saveAndFlush(account);
				Transaction transaction=new Transaction(amount,"Deposit");
				transaction.setAccount(account);
				bankingDAOServicesTransaction.save(transaction);
				return bankingDAOServicesAccount.findOne(accountNo).getAccountBalance();
			}
			else{
				throw new InsufficientAmountException("Insufficient balance for this transaction");
			}
		else {
			Account account=bankingDAOServicesAccount.findOne(accountNo);
			account.setPinCounter(account.getPinCounter()+1);
			bankingDAOServicesAccount.saveAndFlush(account);
			if(bankingDAOServicesAccount.findOne(accountNo).getPinCounter()==3){
				account.setStatus("Blocked");
				bankingDAOServicesAccount.saveAndFlush(account);
			}
			throw new InvalidPinNumberException("Enter Correct Pin");
		}
	}
	
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(bankingDAOServicesCustomer.findOne(customerIdTo)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerIdTo+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNoTo)==null&&bankingDAOServicesAccount.findOne(accountNoTo).getCustomer().getCustomerId()==customerIdTo)
			throw new AccountNotFoundException("Account with Id  "+accountNoTo+" not Found");
		if((bankingDAOServicesAccount.findOne(accountNoTo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Reciever Account is Blocked");
		withdrawAmount(customerIdFrom, accountNoFrom,transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo,transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		return	bankingDAOServicesCustomer.findOne(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return bankingDAOServicesAccount.findOne(accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		Account account= bankingDAOServicesAccount.findOne(accountNo);
		account.setPinNumber(BankingUtility.rand.nextInt(9999));
	   bankingDAOServicesAccount.saveAndFlush(account);
		return  account.getPinNumber();
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if(oldPinNumber==bankingDAOServicesAccount.findOne(accountNo).getPinNumber()) {
			Account account =bankingDAOServicesAccount.findOne(accountNo);
			account.setPinNumber(newPinNumber);
			bankingDAOServicesAccount.saveAndFlush(account);
			return true;
		}
		else throw new InvalidPinNumberException("Invalid old pin\n Enter Correct pin to change the pin");
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingDAOServicesCustomer.findAll();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		
		return new ArrayList<>( bankingDAOServicesCustomer.findOne(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		return new ArrayList<>(bankingDAOServicesAccount.findOne(accountNo).getTransactions().values());
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		if((bankingDAOServicesAccount.findOne(accountNo).getStatus()).equalsIgnoreCase("blocked"))
			throw new AccountBlockedException("Your Account is blocked kindly update Account status");
		return bankingDAOServicesAccount.findOne(accountNo).getStatus();
	}
	@Transactional(propagation = Propagation.REQUIRES_NEW )
	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		if(bankingDAOServicesAccount.findOne(accountNo).getCustomer().getCustomerId()!=customerId)
			throw new AccountNotFoundException("Account with Id  "+accountNo+" not Found");
		 bankingDAOServicesAccount.delete(accountNo);
		 bankingDAOServicesAccount.flush();
		 return true;
	}
@Override
	public boolean removeCustomer(int customerId) throws BankingServicesDownException, CustomerNotFoundException{
		if(bankingDAOServicesCustomer.findOne(customerId)==null)
			throw new CustomerNotFoundException("Customer with customerId  "+customerId+" not Found");
		bankingDAOServicesCustomer.delete(customerId);
		return true;
	}
}
