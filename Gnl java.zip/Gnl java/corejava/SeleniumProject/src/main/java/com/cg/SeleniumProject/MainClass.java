package com.cg.SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass {

	public static void main(String[] args) {
		try {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		WebElement searchElement=driver.findElement(By.id("lst-ib"));
		searchElement.sendKeys("Duke");
		searchElement.submit();
		WebElement imagesLink= driver.findElements(By.linkText("Images")).get(0);
		imagesLink.click();	
		WebElement imageElement=driver.findElements(By.cssSelector("a[class=rg_l]")).get(0);
		WebElement imageLink=imageElement.findElements(By.tagName("img")).get(0);
		imageLink.click();
		} catch (Exception e) {
		 e.printStackTrace();
		}
	}
}