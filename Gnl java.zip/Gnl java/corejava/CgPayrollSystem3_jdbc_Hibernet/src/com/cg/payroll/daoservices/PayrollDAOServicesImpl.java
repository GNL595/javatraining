package com.cg.payroll.daoservices;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;

@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private SessionFactory sessionFactory;
	public PayrollDAOServicesImpl() {
	}
	private Session session;
	@Override
	public int insertAssociate(Associate associate) {	
		session=sessionFactory.openSession();
		int id=(int)session.save(associate);
		session.flush();
		return id;
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		session=sessionFactory.openSession();
		session.update(associate);
		session.flush();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		session=sessionFactory.openSession();
		Associate associate=getAssociate(associateId);
		session.delete(associate);
		session.flush();
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		session=sessionFactory.openSession();
		Associate associate=(Associate) session.get(Associate.class, associateId);
		return associate;
	}

	@Override
	public List<Associate> getAssociate() {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Associate a");
		return query.list();
	/*	List<Associate> assoc=session.createCriteria(Associate.class).list();
		return assoc;*/
	}
	
}