package com.cg.payroll.unittest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.InvalidDataException;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollTest {
private static PayrollServicesImpl services;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new PayrollServicesImpl();
	}

	@AfterClass
	public static void tearDownTestEnv(){
		services=null;
	}

	@Before
	public void setMockData()throws InvalidDataException{
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", new Salary(50000, 1000,1000),new BankDetails(13567899, "HDFC", "HD00978"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", new Salary(10000, 1000,1000),new BankDetails(13555899, "HDFC", "HD00978"));
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", new Salary(20000, 1000,1000),new BankDetails(13577899, "HDFC", "HD00978"));
		
		PayrollDAOServicesImpl.associateList.put(associate1.getAssociateId(), associate1);
		PayrollDAOServicesImpl.associateList.put(associate2.getAssociateId(), associate2);
		PayrollDAOServicesImpl.associateList.put(associate3.getAssociateId(), associate3);
	}

	@After
	public void tearDown(){
		PayrollDAOServicesImpl.associateList.clear();
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
	}

	@Test
	public void validAcceptAssociate() throws InvalidDataException{
		int id=services.acceptAssociate(1000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com",20000, 1000,1000,13577899, "HDFC", "HD00978");
		Assert.assertEquals(114, id);
	}
	@Test(expected=InvalidDataException.class)
	public void invalidAcceptAssociate() throws InvalidDataException{
	services.acceptAssociate(1000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com",-1, 0000,1000,13577899, "HDFC", "HD00978");
	}
	@Test
	public void validGetAssociateDetails() throws AssociateDetailsNotFoundException{
		Associate ass=new Associate(111,150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", new Salary(50000, 1000,1000),new BankDetails(13567899, "HDFC", "HD00978"));
		Assert.assertEquals(ass, services.getAssociateDetails(111));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void invalidGetAssociateDetails() throws AssociateDetailsNotFoundException{
		services.getAssociateDetails(131);
	}
	@Test
	public void validDeleteAssociate()throws AssociateDetailsNotFoundException{
		Assert.assertEquals(true,services.doDeleteAssociate(111));	
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void invalidDeleteAssociate()throws AssociateDetailsNotFoundException{
		services.doDeleteAssociate(131);
	}
	@Test
	public void validCalcNetSal()throws AssociateDetailsNotFoundException{
	float v=(float)services.calculateNetSalary(112);
	Assert.assertEquals(17500.0, v, 0);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void invalidCalcNetSal()throws AssociateDetailsNotFoundException{
	float v=(float)services.calculateNetSalary(122);
	}
}
