package com.cg.project.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.beans.Associate;


public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		Associate associate=(Associate)applicationContext.getBean("associate");
		System.out.println(associate);
		Associate associate2=(Associate)applicationContext.getBean("associate");
		System.out.println(associate);
		if(associate==associate2)
			System.out.println("same ref");
		else
			System.out.println("different ref");
		if(associate.equals(associate2))
			System.out.println("same data");
		else
			System.out.println("different data");
	}

}
