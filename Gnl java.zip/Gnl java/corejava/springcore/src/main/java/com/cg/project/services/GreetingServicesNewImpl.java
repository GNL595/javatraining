package com.cg.project.services;

import org.springframework.stereotype.Component;

public class GreetingServicesNewImpl implements  GreetingServices{

	public GreetingServicesNewImpl() {
		System.out.println("new Impl");
	}

	@Override
	public String sayHello(String name) {
		return "Hello"+" "+name;
	}

	@Override
	public String sayGoodBye(String name) {
		return "GoodBye"+" "+name;
	}

}
