package com.cg.project.services;

public interface GreetingServices{
String	sayHello(String name);
String sayGoodBye(String name);
}
