package com.cg.payroll.beans;

public abstract class AbstractType {

	public AbstractType(){
		System.out.println();
	}
}
