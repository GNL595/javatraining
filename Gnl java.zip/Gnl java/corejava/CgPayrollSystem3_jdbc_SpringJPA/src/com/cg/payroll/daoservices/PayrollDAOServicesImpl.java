package com.cg.payroll.daoservices;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;

@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	public PayrollDAOServicesImpl() {
	}
	private EntityManager entityManager;
	@Override
	public int insertAssociate(Associate associate) {	
		entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateId();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		Associate associate=getAssociate(associateId);
		entityManager.getTransaction().begin();
		//Associate associate=entityManager.find(Associate.class, associateId);
		entityManager.remove(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		entityManager=entityManagerFactory.createEntityManager();
		Associate associate=entityManager.find(Associate.class, associateId);
		return associate;
	}

	@Override
	public List<Associate> getAssociate() {
		entityManager=entityManagerFactory.createEntityManager();
		Query q = entityManager.createQuery("from Associate a", Associate.class);
        return q.getResultList();
	/*	List<Associate> assoc=session.createCriteria(Associate.class).list();
		return assoc;*/
	}
	
}