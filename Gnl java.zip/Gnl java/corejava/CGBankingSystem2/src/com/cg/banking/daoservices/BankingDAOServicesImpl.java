package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class BankingDAOServicesImpl implements BankingDAOServices {
	//private static HashMap<Integer, Customer> customerList=new HashMap<>();
	private static HashMap<Integer, Customer> customerList=new HashMap<>();
	@Override
	public int insertCustomer(Customer customer) {		
		customerList.put(BankingUtility.CUSTOMER_ID_COUNTER, customer);
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_NUM_GENERATOR);
		account.setStatus("Active");
		customerList.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NUM_GENERATOR++, account);
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customerList.get(customerId).getAccounts().replace(account.getAccountNo(),account)!=null)
			return true;
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		getAccount(customerId, account.getAccountNo()).setPinNumber(BankingUtility.rand.nextInt(9999));
		return account.getPinNumber();
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.TRANSACTION_NUM_GENERATOR);
		if(getAccount(customerId, accountNo).getTransactions().put(BankingUtility.TRANSACTION_NUM_GENERATOR++, transaction)!=null)
			return true;
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if(customerList.remove(customerId)!=null)
			return true;
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(customerList.get(customerId).getAccounts().remove(accountNo)!=null)
			return true;
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customerList.get(customerId).getAccounts().get(accountNo);
	}

	@Override
	public ArrayList<Customer> getCustomers() {
		return new ArrayList<Customer>(customerList.values());
	}

	@Override
	public ArrayList<Account> getAccounts(int customerId) {
		return new ArrayList<Account>(customerList.get(customerId).getAccounts().values());
	}
	@Override
	public ArrayList<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<Transaction>(getAccount(customerId, accountNo).getTransactions().values());
	}
	public void doSerialization(File fromFile) throws FileNotFoundException, IOException {
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(fromFile))){
			dest.writeObject(customerList);
		}
	}
	@SuppressWarnings("unchecked")
	public void doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			customerList=(HashMap<Integer, Customer>) src.readObject();

			ArrayList<Integer>var=new ArrayList<Integer> (customerList.keySet());
			BankingUtility.CUSTOMER_ID_COUNTER=Collections.max(var)+1;
			ArrayList<Long>var1=new ArrayList<Long>();
			ArrayList<Integer>var2=new ArrayList<Integer>();
			for(int i=0;i<var.size();i++)
				if( (customerList.get(var.get(i)).getAccounts()!=null))
					var1.addAll(new ArrayList<Long>(customerList.get(var.get(i)).getAccounts().keySet()));	
			if(var1.size()!=0)
				BankingUtility.ACCOUNT_NUM_GENERATOR=Collections.max(var1)+1;
			var1.clear();
			for(int j=0;j<var.size();j++){
				if( (new ArrayList<Long>(customerList.get(var.get(j)).getAccounts().keySet())).size()!=0)
					var1.addAll(new ArrayList<Long>(customerList.get(var.get(j)).getAccounts().keySet()));	
				for(int k=0;k<var1.size();k++){
				if((customerList.get(var.get(j)).getAccounts().get(var1.get(k)).getTransactions()!=null))
						var2.addAll(new ArrayList<Integer>(customerList.get(var.get(j)).getAccounts().get(var1.get(k)).getTransactions().keySet()));
				}
				var1.clear();
			}
			if(var2.size()!=0)
				BankingUtility.TRANSACTION_NUM_GENERATOR=Collections.max(var2)+1;
		}
	} 
}