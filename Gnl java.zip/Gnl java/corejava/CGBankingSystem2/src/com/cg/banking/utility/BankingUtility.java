package com.cg.banking.utility;
import java.util.Random;
public class BankingUtility {
	public static Random rand= new Random();
	public static int CUSTOMER_ID_COUNTER=1000;
	public static long ACCOUNT_NUM_GENERATOR=10000000;
	public static int TRANSACTION_NUM_GENERATOR=1000;
	
}
