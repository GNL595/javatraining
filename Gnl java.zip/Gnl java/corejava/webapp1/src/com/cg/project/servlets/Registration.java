package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.User;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init(ServletConfig config) throws ServletException {	

	}

	public void destroy() {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String emailId=request.getParameter("emailId");
		String password=request.getParameter("password");		
		String reEnterPassword=request.getParameter("reEnterPassword");
		String gender=request.getParameter("gender");
		String[] communication=request.getParameterValues("communication");
		String graduation=request.getParameter("graduation");
		String description=request.getParameter("description");
		String resume=request.getParameter("resume");
		writer.println("<font color= 'blue' size=5>");
		writer.println("firstname: " +firstName );
		writer.println("<br>");
		writer.println("lastname: " +lastName );
		writer.println("<br>");
		writer.println("username: " +userName );
		writer.println("<br>");
		writer.println("password: " +password );
		writer.println("<br>");
		writer.println("reEnterPassword: " +reEnterPassword);
		writer.println("<br>");
		writer.println("gender: " +gender );
		writer.println("<br>");
		writer.println("communication: " );
		if(communication.length!=0)
			for(int i=0;i<communication.length;i++)
				writer.println(communication[i]);
		writer.println("<br>");
		writer.println("description: " +description );
		writer.println("<br>");
		writer.println("resume: " +resume );
		writer.println("<br>");
		if(firstName.isEmpty()||lastName.isEmpty()||userName.isEmpty()||password.isEmpty()||reEnterPassword.isEmpty()||gender.isEmpty()||communication.length==0)
		{
			RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
			request.setAttribute("errorMessage", "all the field are mandatory. empty fields are not allowed");
			rd.forward(request, response);
		}
		else{
			if(password.equals(reEnterPassword)){
				User user =new User(firstName, lastName, emailId, userName, password, reEnterPassword, gender, graduation, description, communication);
				RequestDispatcher rd= request.getRequestDispatcher("SucessRegServlet");
				request.setAttribute("user", user);
				System.out.println(user);
				rd.forward(request, response);	
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", "password and re-enter password are not same");
				rd.forward(request, response);
			}
		}

	}
}