package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.User;

@WebServlet("/SucessRegServlet")
public class SucessRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	public void init(){
		ServletContext servletcontext=getServletContext();
		con=(Connection) servletcontext.getAttribute("con");
		System.out.println("init started");
	}

	public void destroy() {
		con=null;
		System.out.println("destoryed bum bum bum");
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
		PrintWriter writer = response.getWriter();
		User user=(User) request.getAttribute("user");
		writer.println("<font color='green' size=10>Sucessfully Registered</font>");
		PreparedStatement psmt1=con.prepareStatement("insert into login(userName,password,firstName,lastName,emailId,gender,graduation,description)values(?,?,?,?,?,?,?,?)");
		psmt1.setString(1,user.getUserName());
		psmt1.setString(2,user.getPassword());
		psmt1.setString(3,user.getFirstName());
		psmt1.setString(4,user.getLastName());
		psmt1.setString(5,user.getEmailId());
		psmt1.setString(6,user.getGender());
		psmt1.setString(7,user.getGraduation());
		psmt1.setString(8,user.getDescription());
		psmt1.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}
