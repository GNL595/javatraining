package com.cg.project.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.project.bean.User;

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	public void init(){
		ServletContext servletcontext=getServletContext();
		con=(Connection) servletcontext.getAttribute("con");
		System.out.println("init started");
	}

	public void destroy() {
		con=null;
		System.out.println("destoryed bum bum bum");
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("service");
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");		
			//PrintWriter writer=response.getWriter();
			RequestDispatcher dispatcher; 
			User user=new User(userName,password);
			PreparedStatement psmt=con.prepareStatement("select password from login where userName=?");
			psmt.setString(1, userName);
			ResultSet rs = psmt.executeQuery();
			if(rs.next()){
				if(rs.getString("password").equals(password)){
					dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
					request.setAttribute("user", user);
					dispatcher.forward(request, response);
				}
				else{
					dispatcher=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", "UserName or password wrong plz try again");
					dispatcher.forward(request, response);
				}
			} 
			else{
				dispatcher=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", "UserName not found");
				dispatcher.forward(request, response);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}