package com.cg.payroll.daoservices;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.*;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	public static HashMap<Integer,Associate> associateList = new HashMap<>();
	
	public int insertAssociate(Associate associate){
		associateList.put( PayrollUtility.ASSOCIATE_ID_COUNTER, associate);
		associate.setAssociateId(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateId();
	}

	public boolean updateAssociate(Associate associate){
		if(associateList.get(associate.getAssociateId())!= null){
			associateList.replace(associate.getAssociateId(),associate);
			return true;
		}
		return false;
	}

	public boolean deleteAssociate(int associateId){
			if(associateList.remove(associateId)!= null)
				return true;
		return false;
	}

	public Associate getAssociate(int associateId){
		return associateList.get(associateId);
	}

	public List<Associate> getAssociate(){
		return new ArrayList(associateList.values());
	}
}