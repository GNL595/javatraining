package com.cg.serializable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializableDemo implements Serializable{
	
	public Object doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			return src.readObject();
		}
	}

	public void doSerialization(File fromFile,Associate associate) throws FileNotFoundException, IOException {
		//Associate associate=new Associate(11,11, "v"	,"j","it", "a","abc", "abc@gmail.com");
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(fromFile))){
			dest.writeObject(associate);
		}
		System.out.println(associate+" "+fromFile.getAbsolutePath());
	} 
} 
