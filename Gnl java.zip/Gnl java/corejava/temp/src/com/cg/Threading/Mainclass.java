package com.cg.Threading;

public class Mainclass {

	public static void main(String[] args) throws InterruptedException {
		Threading thr=new Threading();
		Thread t1=new Thread(thr,"thread-1");
		Thread t2=new Thread(thr,"thread-2");
		t1.start();
		t1.setPriority(6);
		t2.start();
		t2.join();
	}
	}
		/*Threading t1=new Threading("thread-1");
		t1.start();
		Threading t2=new Threading("thread-2");
		t2.start();
	}

}*/
