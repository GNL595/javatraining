package com.cg.project.services;

import com.cg.project.Exception.InvalidNoRangeException;

public class MainClass {
	public static void main(String[] args) {
		int a=10,b=0;
		try{
			MathServicesImpl math =new MathServicesImpl();
			System.out.println(math.add(a,b)+" "+math.sub(a,b)+" "+math.div(a,b));
		}
		catch(InvalidNoRangeException e){
			e.printStackTrace();
		}
	}
}
