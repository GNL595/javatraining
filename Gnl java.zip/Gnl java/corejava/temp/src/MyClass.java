import java.io.IOException;

class MyClass{
      		public static void main(String [] str){
      			try{
             			System.out .println("Hello");
            			new IOException();
        			}
        			catch(IOException ex){
         				System.out.println("exception ");
        			}
        			System.out.println("world") ;
         			finally{
         				System.out.println("finally");
          			}
     		}
	}
