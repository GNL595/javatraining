package com.cg.payroll.utility;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class AssociateMapper implements RowMapper<Associate> {

	@Override
	public Associate mapRow(ResultSet resultSet, int i) throws SQLException {
		Associate associate=new Associate();
		associate.setAssociateId(resultSet.getInt("associateId"));
		associate.setFirstName(resultSet.getString("firstName"));
		associate.setLastName(resultSet.getString("lastName"));
		associate.setDepartment(resultSet.getString("department"));
		associate.setDesignation(resultSet.getString("designation"));
		associate.setPancard(resultSet.getString("pancard"));
		associate.setEmailId(resultSet.getString("emailId"));
		associate.setYearlyInvestmentUnder80C(resultSet.getInt("yearlyInvestmentUnder80C"));
		BankDetails bankDetails=new BankDetails(resultSet.getInt("accountNumber"), resultSet.getString("bankName"), resultSet.getString("ifscCode"));
		associate.setBankdetails(bankDetails);
		Salary salary=new Salary(resultSet.getDouble("basicSalary"),resultSet.getDouble("hra"),resultSet.getDouble("conveyenceAllowance"),resultSet.getDouble("otherAllowance"),resultSet.getDouble("personalAllowance"),resultSet.getDouble("monthlyTax"),resultSet.getDouble("epf"),resultSet.getDouble("companyPf"),resultSet.getDouble("gratuity"),resultSet.getDouble("grossSalary"),resultSet.getDouble("netSalary"));
		associate.setSalary(salary);
		return associate;
	}

}
