package Com.CG.HousingDotCom.Beans;

public class CustomerList {
	private int noOfCustomerSearched;
	private String nameOfCustomer,customerFeedback;
	public CustomerList() {}
	public CustomerList(int noOfCustomerSearched, String nameOfCustomer, String customerFeedback) {
		super();
		this.noOfCustomerSearched = noOfCustomerSearched;
		this.nameOfCustomer = nameOfCustomer;
		this.customerFeedback = customerFeedback;
	}
	public int getNoOfCustomerSearched() {
		return noOfCustomerSearched;
	}
	public void setNoOfCustomerSearched(int noOfCustomerSearched) {
		this.noOfCustomerSearched = noOfCustomerSearched;
	}
	public String getNameOfCustomer() {
		return nameOfCustomer;
	}
	public void setNameOfCustomer(String nameOfCustomer) {
		this.nameOfCustomer = nameOfCustomer;
	}
	public String getCustomerFeedback() {
		return customerFeedback;
	}
	public void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}
	
	

}
