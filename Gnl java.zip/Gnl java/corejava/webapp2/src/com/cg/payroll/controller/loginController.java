package com.cg.payroll.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class loginController {

	@Autowired
	PayrollServices payrollServices;

	@RequestMapping(value="/caluculateSalary")
	public String registerUser(@ModelAttribute("associate")Associate associate){
		try {
			try {
				payrollServices.calculateNetSalary(associate.getAssociateId());
				associate.setBankdetails(payrollServices.getAssociateDetails(associate.getAssociateId()).getBankdetails());
				associate.setSalary(payrollServices.getAssociateDetails(associate.getAssociateId()).getSalary());
				System.out.println(associate);
				return "Salary";
			} catch (AssociateDetailsNotFoundException e) {
				return "errorPage";
			}
		} catch (PayrollServicesDownException e) {
			return "errorPage";
		}
	}
}
