package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollServices {

	int acceptAssociate(Associate associate)throws InvalidDataException,PayrollServicesDownException;

	boolean doUpdateAssociate(int associateId, int yearlyInvestmentUnder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode)
			throws AssociateDetailsNotFoundException,PayrollServicesDownException;

	double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	boolean doDeleteAssociate(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	List<Associate> getAllAssociateDetails() throws PayrollServicesDownException;

}