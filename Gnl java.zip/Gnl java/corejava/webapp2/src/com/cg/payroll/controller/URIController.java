package com.cg.payroll.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;

@Controller
public class URIController {
	

	@RequestMapping(value="/")
	public String getIndexPage(){
		return "Index";
	}
	@RequestMapping(value="/loginPage")
	public String getLoginPage(){
		return "loginPage";
	}
	@RequestMapping(value="/registrationPage")
	public String getRegistrationPage(){
		return "registrationPage";
	}
	@ModelAttribute(value="associate")
	public Associate getAssociate(){
		return new Associate();
	}
}
