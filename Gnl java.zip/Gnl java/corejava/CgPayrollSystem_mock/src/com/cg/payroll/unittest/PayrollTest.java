package com.cg.payroll.unittest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidDataException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollTest {
	private static PayrollServices payrollServices;
	private static PayrollDAOServices mockDaoServices;
	@BeforeClass
	public static void setUpTestEnv(){
		mockDaoServices=Mockito.mock(PayrollDAOServices.class);
		payrollServices=new PayrollServicesImpl(mockDaoServices);
	}
	@AfterClass
	public static void tearDownEnv(){
		payrollServices=null;
	}
	@Before
	public void setUpMockData(){
		Associate associate1=new Associate(111, 150000, "V", "J", "IT", "ANALYST", "ABC1", "ABC@GMAIL.COM",
				new Salary(300000, 1000,1000),new BankDetails(1000, "sbi", "sbin001"));
		Associate associate2=new Associate(112, 120000, "V", "JSC", "IT", "ANALYST", "ABC2", "ABC@GMAIL.COM",
				new Salary(15000, 1000,1000),new BankDetails(1000, "sbi", "sbin002"));
		List<Associate>	associates=new ArrayList<>();
		associates.add(associate1);
		associates.add(associate2);
		Mockito.when(mockDaoServices.getAssociate(111)).thenReturn(associate1);
		Mockito.when(mockDaoServices.getAssociate(112)).thenReturn(associate2);
		Mockito.when(mockDaoServices.getAssociate(100)).thenReturn(null);
		Associate associate3=new Associate(1, "v", "v", "IT", "analyst", "abc100", "abc@gmail.com", new Salary(1000, 100, 100), new BankDetails(1, "sbi", "abc100"));
		associates.add(associate3);
		Mockito.when(mockDaoServices.insertAssociate(associate3)).thenReturn(113);
		Mockito.when(mockDaoServices.getAssociates()).thenReturn(associates);
		
		Mockito.when(mockDaoServices.deleteAssociate(114)).thenReturn(false);
		Mockito.when(mockDaoServices.deleteAssociate(111)).thenReturn(true);
		
	}
	@Test			
	public void acceptAssociateDetailsForValidData()throws InvalidDataException {
		Associate associate=new Associate(1, "v", "v", "IT", "analyst", "abc100", "abc@gmail.com", new Salary(1000, 100, 100), new BankDetails(1, "sbi", "abc100"));
		
		assertEquals(113, payrollServices.acceptAssociate(1,"v", "v", "abc@gmail.com", "IT", "analyst", "abc100", 1000, 100, 100, 1, "sbi", "abc100"));
		Mockito.verify(mockDaoServices).insertAssociate(associate);
	}
	@Test			
	public void acceptAssociateDetailsForInValidData() throws InvalidDataException {
		Associate associate=new Associate(1, "v", "v", "IT", "analyst", "abc100", "abc@gmail.com", new Salary(1000, 100, 100), new BankDetails(1, "sbi", "abc100"));
		
		assertNotEquals(117, payrollServices.acceptAssociate(10000,"v", "v", "abc@gmail.com", "IT", "analyst", "abc100", 1000, 100, 100, 1, "sbi", "abc100"));
		Mockito.verify(mockDaoServices).insertAssociate(associate);
	
	}
	@Test
	public void testAssociateDetailsForValidData() throws AssociateDetailsNotFoundException{
		Associate associate=new Associate(111, 150000, "V", "J", "IT", "ANALYST", "ABC1", "ABC@GMAIL.COM",
				new Salary(300000, 1000,1000),new BankDetails(1000, "sbi", "sbin001"));
	
		assertEquals(associate,payrollServices.getAssociateDetails(111));
		Mockito.verify(mockDaoServices).getAssociate(111);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testAssociateDetailsForInValidData() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(100);
	}
	@Test
	public void testDeleteAssociate() throws AssociateDetailsNotFoundException{
		assertTrue(payrollServices.doDeleteAssociate(111));
		Mockito.verify(mockDaoServices).deleteAssociate(111);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testDeleteAssociateInValidData() throws AssociateDetailsNotFoundException{
		payrollServices.doDeleteAssociate(114);
		Mockito.verify(mockDaoServices).deleteAssociate(114);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testNetSalaryInValidData() throws AssociateDetailsNotFoundException{
		payrollServices.calculateNetSalary(114);
		Mockito.verify(mockDaoServices).getAssociate(114);
	}
	@Test
	public void testNetSalaryValidData() throws AssociateDetailsNotFoundException{
		assertEquals(403033.34375,payrollServices.calculateNetSalary(111),0);
		Mockito.verify(mockDaoServices).getAssociate(111);

	}
	@After
	public void tearDownMockData(){
		Mockito.reset(mockDaoServices);
	}

}
