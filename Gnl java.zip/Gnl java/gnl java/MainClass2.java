public class MainClass2{
	public static void main(String [] str){
                int j=0;
		for(int i=0;i<11;i++){
		j=j+i;
                System.out.println("+"+i);
		}
		System.out.println("="+j);
	}
}