package com.cg.baseproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/page4")
public class page4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body style='background-color: powderblue;'>");
		out.println("<div align=center>");
		out.println("<table><tr><td>firstName: </td> <td>"+firstName+"</td></tr>");
		out.println("<tr><td>lastName: </td><td>"+lastName+"</td></tr>");
		out.println("<tr><td>city: </td><td>"+city+"</td></tr>");
		out.println("<tr><td>state: </td><td>"+state+"</td></tr>");
		out.println("<tr><td>phone: </td><td>"+phone+"</td></tr>");
		out.println("<tr><td>email: </td><td>"+email+"</td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
