package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.User;

@WebServlet("/page4")
public class page4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(){

	}

	public void destroy() {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		ServletContext context = getServletContext();
		User user=(User)context.getAttribute("user");
		user.setPhone(phone);
		user.setEmail(email);
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body style='background-color: powderblue;'>");
		out.println("<div align=center>");
		out.println("<table><tr><td>firstName: </td> <td>"+user.getFirstName()+"</td></tr>");
		out.println("<tr><td>lastName: </td><td>"+user.getLastName()+"</td></tr>");
		out.println("<tr><td>city: </td><td>"+user.getCity()+"</td></tr>");
		out.println("<tr><td>state: </td><td>"+user.getState()+"</td></tr>");
		out.println("<tr><td>phone: </td><td>"+user.getPhone()+"</td></tr>");
		out.println("<tr><td>email: </td><td>"+user.getEmail()+"</td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
