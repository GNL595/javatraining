package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.User;

@WebServlet("/page2")
public class page2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() {

	}

	public void destroy() {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		User user=new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		ServletContext context = getServletContext();
		context.setAttribute("user", user);
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body style='background-color: powderblue;'>");
		out.println("<div align=center>");
		out.println("<table><tr><td>firstName: </td> <td>"+firstName+"</td></tr>");
		out.println("<tr><td>lastName: </td><td>"+lastName+"</td></tr>");
		out.println("<form name='page2' action='page3' method='post'>");
		out.println("<tr><td>city: </td><td><input type='text' name='city'></td></tr>");
		out.println("<tr><td>state: </td><td><input type='text' name='state'></td></tr>");
		out.println("<tr><td><input type='submit' value='submit'></td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
