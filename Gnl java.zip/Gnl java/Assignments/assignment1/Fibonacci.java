public class Fibonacci{
	public static void main(String [] str){
		int i=0,j=1,fib,n=11;
		System.out.print(i+" "+j+" ");
		for(int m=0;m<n;m++){
			fib=i+j;
			System.out.print(fib+" ");
			i=j;
			j=fib;
		}
	}
}