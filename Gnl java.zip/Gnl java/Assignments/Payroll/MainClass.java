public class MainClass{
	public static void main(String[] str){
		Associate associate1=new Associate(223,123,"Ravi","teja","java","soft","fr","ravigmail");
		associate1.setAssociateId(22);
		System.out.println(associate1.getAssociateId()+" "+associate1.getFirstName()+" "+associate1.getLastName());		
	}
}