public class MainClass7{
	public static void main(String [] str){
		for(int i=1;i<=10;i++){
			for(int j=10;j<i;j--)
			System.out.print(" ");
			for(int j=10;j<=i;j--)
			System.out.print(i);
		System.out.println(" ");
		 }
	}
}