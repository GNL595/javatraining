public class MainClass{
	public static void main(String [] str){
		for(int i=1;i<11;i++){
			for(int j=1;j<21;j++){
				System.out.print(i*j+"\t");
				}
				System.out.println(" ");
		 }
	}
}