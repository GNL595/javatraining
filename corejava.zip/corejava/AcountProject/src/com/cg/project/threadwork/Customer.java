package com.cg.project.threadwork;
import com.cg.project.beans.*;

public class Customer implements Runnable{
public Customer() {}
private  static Account account;
static {
	account=new Account(10000);
	System.out.println("Initial Balance  :-" + account.getBalance()
	+"\n\n================================");
}
@Override
	public void run() {
		Thread customerThread = Thread.currentThread();
		if(customerThread.getName().equals("ravi")){
			for(int i=1;i<=5;i++)
				try{
					Thread.sleep(100);
					System.out.println("\n"+customerThread.getName()+" has call withdraw()" + i + "time balance :="+account.withdraw(5000));
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		
		if(customerThread.getName().equals("teja")){
			for(int i=1;i<=5;i++)
				try{
					Thread.sleep(100);
					System.out.println("\n"+ customerThread.getName()+" has call deposit()" + i + "time balance :="+account.deposit(1000));
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		
if(customerThread.getName().equals("gnl")){
	for(int i=1;i<=5;i++)
		try{
			Thread.sleep(100);
			System.out.println("\n"+ customerThread.getName()+" has call checkBalance()" + i + "time balance :="+account.getBalance());
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
	
}
