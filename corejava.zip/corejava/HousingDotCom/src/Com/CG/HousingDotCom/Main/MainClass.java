package Com.CG.HousingDotCom.Main;

import Com.CG.HousingDotCom.Beans.FlatAvailability;
import Com.CG.HousingDotCom.Beans.FlatLocation;

public class MainClass {

	public static void main(String[] args) {
		FlatLocation flatlocation=new FlatLocation();
		FlatAvailability flatavailability=new FlatAvailability(101,200000,"200*500","cash","Buy");
		System.out.println(flatavailability.getFlatCost());
		
		
		

	}

}
