package com.cg.project.beans;

public class SalesManager extends PEmployee{
	private int commision,salesAmount;
	public SalesManager() {
		super();
	}
	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName, int salesAmount) {
		super(employeeId, basicSalary, firstName, lastName);
		this.salesAmount = salesAmount;
	}
	public int getCommision() {
		return commision;
	}
	public void setCommision(int commision) {
		this.commision = commision;
	}
	public int getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(int salesAmount) {
		this.salesAmount = salesAmount;
	}
	public final void calculateSalary(){
		super.calculateSalary();
		this.commision=(int)(0.1*(this.getSalesAmount()));
		this.setTotalSal(this.getTotalSal()+this.commision);
	}
	public String toString() {
		return super.toString() +"SalesManager " +"Commision"+commision;
	}
}
