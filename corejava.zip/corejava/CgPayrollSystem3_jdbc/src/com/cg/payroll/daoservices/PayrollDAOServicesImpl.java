package com.cg.payroll.daoservices;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.*;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	private Connection conn=null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownException {
		conn=PayrollUtility.getDBConnection();
	}
	@Override
	public int insertAssociate(Associate associate) throws  SQLException{
		try{
			conn.setAutoCommit(false);
			PreparedStatement psmt1=conn.prepareStatement("insert into associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId)values(?,?,?,?,?,?,?)");
			psmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			psmt1.setString(2, associate.getFirstName());			
			psmt1.setString(3, associate.getLastName());			
			psmt1.setString(4, associate.getDepartment());			
			psmt1.setString(5, associate.getDesignation());			
			psmt1.setString(6, associate.getPancard());			
			psmt1.setString(7, associate.getEmailId());			
			psmt1.executeUpdate();
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(associateId) from Associate");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			PreparedStatement psmt3=conn.prepareStatement("insert into bankdetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			psmt3.setInt(1, associateId);
			psmt3.setInt(2, associate.getBankdetails().getAccountNumber());
			psmt3.setString(3, associate.getBankdetails().getBankName());
			psmt3.setString(4, associate.getBankdetails().getIfscCode());
			psmt3.executeUpdate();
			
			PreparedStatement psmt4=conn.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			psmt4.setInt(1, associateId);
			psmt4.setDouble(2,  associate.getSalary().getBasicSalary());
			psmt4.setDouble(3, associate.getSalary().getEpf());
			psmt4.setDouble(4, associate.getSalary().getCompanyPf());
			psmt4.executeUpdate();
			
			conn.commit();
			return associateId;
		}
		catch(SQLException e){
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
	/*	try{
			conn.setAutoCommit(false);
			int a=associate.getAssociateId();
			PreparedStatement pstmt2 = conn.prepareStatement("SELECT count(*) FROM associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			for(int i=1;i<10;i++)
			int associateId = rs.ge
		}
			catch(SQLException e){
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}*/
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {
		
		return null;
	}

	@Override
	public List<Associate> getAssociate() {

		return null;
	}
	
}