package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidDataException;

public interface PayrollServices {

	int acceptAssociate(int yearlyInvestmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode)throws InvalidDataException;

	boolean doUpdateAssociate(int associateId, int yearlyInvestmentUnder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode)
			throws AssociateDetailsNotFoundException;

	double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;

	boolean doDeleteAssociate(int associateId)throws AssociateDetailsNotFoundException;

	List<Associate> getAllAssociateDetails();

}