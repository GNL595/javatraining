package com.cg.Threading;

public class Threading implements Runnable{

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(t.getName().equals("thread-1"))
			for(int i=1;i<100;i++){
				if(i %2==0)
				System.out.print(i+" ");
			}
		else if(t.getName().equals("thread-2"))
			for(int i=1;i<100;i++){
				if(i %2!=0)
				System.out.print(i+" ");
			}
		System.out.println("execution of "+t.getName()+"completed");
	}
}

	/*public class Threading extends Thread {
		super();
	}
	public Threading(String name) {
		super(name);
	}
	@Override
	public void run(){
		if(this.getName().equals("thread-1"))
			for(int i=1;i<100;i++){
				if(i %2==0)
				System.out.print(i+" ");
			}
		else if(this.getName().equals("thread-2"))
			for(int i=1;i<100;i++){
				if(i %2!=0)
				System.out.print(i+" ");
			}
		System.out.println("execution of "+this.getName()+"completed");
	}
}*/
