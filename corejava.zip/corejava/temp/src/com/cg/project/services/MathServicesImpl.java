package com.cg.project.services;

import com.cg.project.Exception.InvalidNoRangeException;

public class MathServicesImpl implements MathServices{
	public int add(int n1, int n2)throws InvalidNoRangeException{
		if(n1<0||n2<=0)
			throw new InvalidNoRangeException("Enter valid positive numbers");
		return n1+n2;
	}
	public int sub(int n1, int n2)throws InvalidNoRangeException{
		if(n1<0||n2<=0)
			throw new InvalidNoRangeException("Enter valid positive numbers");
		return n1-n2;
	}
	public float div(int n1, int n2)throws InvalidNoRangeException{
		if(n1<0||n2<=0)
			throw new InvalidNoRangeException("Enter valid positive numbers and divisor should not be zero");
		return n1/n2;
	}
}