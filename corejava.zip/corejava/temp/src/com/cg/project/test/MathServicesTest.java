package com.cg.project.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.project.Exception.InvalidNoRangeException;
import com.cg.project.services.MathServices;
import com.cg.project.services.MathServicesImpl;
public class MathServicesTest {
	private static MathServices services;
	private int validNum1,validNum2,invalidNum1,invalidNum2,expectedAns;
	@BeforeClass
	public static void  setUpTestEnv(){
		services=new MathServicesImpl();
	}
	@Before
	public void setUpMockData(){
		validNum1=100;
		validNum2=10;
		invalidNum1=-10;
		invalidNum2=-10;
	}
	@Test (expected=InvalidNoRangeException.class)
	public void testAddForBothInvalidNo()throws InvalidNoRangeException{
		services.add(invalidNum1, invalidNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testAddForFirstInvalidNo()throws InvalidNoRangeException{
		services.add(invalidNum1, validNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testAddForSecondInvalidNo()throws InvalidNoRangeException{
		services.add(validNum1, invalidNum2);
	}
	@Test
	public void testAddForvalidNo()throws InvalidNoRangeException{
		int actualAns=110;
		expectedAns=services.add(validNum1, validNum2);
		Assert.assertEquals(actualAns,expectedAns);
	}
	@Test (expected=InvalidNoRangeException.class)
	public void testSubForBothInvalidNo()throws InvalidNoRangeException{
		services.sub(invalidNum1, invalidNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testSubForFirstInvalidNo()throws InvalidNoRangeException{
		services.sub(invalidNum1, validNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testSubForSecondInvalidNo()throws InvalidNoRangeException{
		services.sub(validNum1, invalidNum2);
	}
	@Test
	public void testSubForvalidNo()throws InvalidNoRangeException{
		int actualAns=90;
		expectedAns=services.sub(validNum1, validNum2);
		Assert.assertEquals(actualAns,expectedAns);
	}
	@Test (expected=InvalidNoRangeException.class)
	public void testDivForBothInvalidNo()throws InvalidNoRangeException{
		services.div(invalidNum1, invalidNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testDivForFirstInvalidNo()throws InvalidNoRangeException{
		services.div(invalidNum1, validNum2);
	}
	@Test  (expected=InvalidNoRangeException.class)
	public void testDivForSecondInvalidNo()throws InvalidNoRangeException{
		services.div(validNum1, invalidNum2);
	}
	@Test
	public void testDivForvalidNo()throws InvalidNoRangeException{
		int actualAns=10;
		expectedAns=(int) services.div(validNum1, validNum2);
		Assert.assertEquals(actualAns,expectedAns);
	}
	@After
public void tearUpMockData(){
		validNum1=0;
		validNum2=0;
		invalidNum1=0;
		invalidNum2=0;
		expectedAns=0;
	}
	@AfterClass
public static void tearUpTestEnv(){
		services=null;
	}
}
