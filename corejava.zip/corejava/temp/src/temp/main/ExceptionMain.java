package temp.main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionMain {

	public static void main(String[] args) {
		long a,b,c;
		String d;
		Scanner sc=new Scanner(System.in);
		try{
		System.out.println("enter first number");
		a=sc.nextLong();
		sc=new Scanner(System.in);
		System.out.println("enter second number");
		b=sc.nextLong();
		sc=new Scanner(System.in);
		d=sc.nextString();
			c=a/b;
			System.out.println("the result is "+ c);
			System.out.println("the arthimatic operation is complete");
		}
		catch(InputMismatchException e){
			System.out.println("enter only integer");
			e.printStackTrace();
		}
		catch(ArithmeticException e){
			System.out.println("second number is used to divide so it shouldn't be 0");
			e.printStackTrace();
		}
		catch(Exception e){
			System.out.println("check the error description");
			e.printStackTrace();
		}
	}

}
