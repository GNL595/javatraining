package temp.main;
import temp.beans.Pemployee;

public class InheritMain {
	public static void main(String[] args) {
		Pemployee pemp=new Pemployee(115,10000, "ravi", "teja", 5000, 3000, 2000);
		
	}
}
