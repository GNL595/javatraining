package com.cg.collections.main;

import com.cg.collections.ListClassDemo;

public class MainClass {

	public static void main(String[] args) {
		ListClassDemo classDemo=new ListClassDemo();
		classDemo.arrayListClassWork();
		
	}

}
