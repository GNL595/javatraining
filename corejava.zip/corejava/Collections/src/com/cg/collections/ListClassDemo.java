package com.cg.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.cg.collections.beans.Customer;

public class ListClassDemo {
	public static void arrayListClassWork(){
	ArrayList<String> strList=new ArrayList<>();
	strList.add("ravi");
	strList.add("ravi1");
	strList.add("ravi2");
	strList.add(0,"ravi3");
	System.out.println(strList.toString());
	Collections.sort(strList);
	System.out.println(strList);
	System.out.println(strList.toString());
	System.out.println(strList.size());
	System.out.println(strList.get(3));
	Iterator<String> iterator=strList.iterator();
	while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
	ArrayList<Customer> customerList=new ArrayList<>();
	customerList.add(new Customer(4, "ravi4", "tej1"));
	customerList.add(new Customer(2, "ravi5", "tej2"));
	customerList.add(new Customer(3, " ravi6", "tej3"));
	Customer customerToBeSearched=new Customer(2, "ravi5", "tej2");
	Collections.sort(customerList);
	
	System.out.println(customerList.toString());
	
	for(Customer customer:customerList)
		System.out.println(customer);
	
	
	}
}
