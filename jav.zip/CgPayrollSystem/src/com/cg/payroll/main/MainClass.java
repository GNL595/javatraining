package com.cg.payroll.main;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args){
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();
	//	int associatesToBeSearched=10000;
	//	String nameToBeSearched="Ravi";
	//	Associate associate=searchAssociate(associatesToBeSearched,nameToBeSearched);
	//	if(associate!=null)
	//		System.out.println(associate.getAssociateId()+" "+associate.getFirstName()+" "+associate.getLastName()+" "+associate.getSalary().getBasicSalary());
	//	else
	//		System.out.println("associateDetails not found according to condition");
	//}
	//public static Associate searchAssociate(int InvestmentUnder80C,String firstname ){
	//Associate [] associates=new Associate[4];
	//associates[0]=new Associate(123, 54567, "Ravi", "Teja", "JAVA", "Sr.junior", "CC45C7", "ravi@gmail.com",new Salary(30000, 1000, 00, 00, 00, 00, 000, 00, 00, 00, 00),new BankDetails(12345, "HDFC", "HD009"));
    // associates[1]=new Associate(113, 44567, "chethan", "namala", "Microsoft", "Sr.junior", "PP45C7", "chethan@gmail.com",new Salary(20000, 1000, 00, 00, 00, 00, 000, 00, 00, 00, 00),new BankDetails(12305, "HDFC", "HD009"));
     //associates[2]=new Associate(103, 10567, "Ravi", "varma", "Sap", "Junior", "DD45C7", "ravivarma@gmail.com",new Salary(20000, 1000, 00, 00, 00, 00, 000, 00, 00, 00, 00),new BankDetails(12045, "HDFC", "HD009"));
    //for(Associate associate:associates)
    //if(associate!=null&&associate.getFirstName()==firstname&& associate.getYearlyInvestmentUnder80C()>=InvestmentUnder80C&&associate.getSalary().getBasicSalary()>=25000)
    //		return associate;
    //return null;
	}
}