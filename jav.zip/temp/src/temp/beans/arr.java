package temp.beans;
public class arr {
	private int []a=new int[5];
	public arr(int[] a) {
		super();
		this.a = a;
	}
	public int[] getA() {
		return a;
	}
	public void setA(int[] a) {
		this.a = a;
	}	
}