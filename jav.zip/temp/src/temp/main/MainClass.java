package temp.main;
import temp.beans.OneTwo;
public class MainClass {
	public static void main(String[] args) {
		OneTwo numb1=new OneTwo(10);
		OneTwo numb=new OneTwo();
		System.out.println(OneTwo.getCount());
	}
}