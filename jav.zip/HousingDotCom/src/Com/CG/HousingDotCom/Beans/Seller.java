package Com.CG.HousingDotCom.Beans;

public class Seller {
private String nameOfSeller;
private long mobileNo;
public Seller() {}
public Seller(String nameOfSeller, long mobileNo) {
	super();
	this.nameOfSeller = nameOfSeller;
	this.mobileNo = mobileNo;
}
public String getNameOfSeller() {
	return nameOfSeller;
}
public void setNameOfSeller(String nameOfSeller) {
	this.nameOfSeller = nameOfSeller;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}

}
