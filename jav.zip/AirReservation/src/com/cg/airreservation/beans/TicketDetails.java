package com.cg.airreservation.beans;
public class TicketDetails {
private int flightId,luggageLimit,gateNo;
private float ticketPrice;
private String arrivalTime,departureTime,startingPoint,boardingPoint,classType;
private TransactionDetails transactionDetails;
public TicketDetails(int flightId, int luggageLimit, int gateNo, float ticketPrice, String arrivalTime,
		String departureTime, String startingPoint, String boardingPoint, String classType,
		TransactionDetails transactionDetails) {
	super();
	this.flightId = flightId;
	this.luggageLimit = luggageLimit;
	this.gateNo = gateNo;
	this.ticketPrice = ticketPrice;
	this.arrivalTime = arrivalTime;
	this.departureTime = departureTime;
	this.startingPoint = startingPoint;
	this.boardingPoint = boardingPoint;
	this.classType = classType;
	this.transactionDetails = transactionDetails;
}
public int getFlightId() {
	return flightId;
}
public void setFlightId(int flightId) {
	this.flightId = flightId;
}
public int getLuggageLimit() {
	return luggageLimit;
}
public void setLuggageLimit(int luggageLimit) {
	this.luggageLimit = luggageLimit;
}
public int getGateNo() {
	return gateNo;
}
public void setGateNo(int gateNo) {
	this.gateNo = gateNo;
}
public float getTicketPrice() {
	return ticketPrice;
}
public void setTicketPrice(float ticketPrice) {
	this.ticketPrice = ticketPrice;
}
public String getArrivalTime() {
	return arrivalTime;
}
public void setArrivalTime(String arrivalTime) {
	this.arrivalTime = arrivalTime;
}
public String getDepartureTime() {
	return departureTime;
}
public void setDepartureTime(String departureTime) {
	this.departureTime = departureTime;
}
public String getStartingPoint() {
	return startingPoint;
}
public void setStartingPoint(String startingPoint) {
	this.startingPoint = startingPoint;
}
public String getBoardingPoint() {
	return boardingPoint;
}
public void setBoardingPoint(String boardingPoint) {
	this.boardingPoint = boardingPoint;
}
public String getClassType() {
	return classType;
}
public void setClassType(String classType) {
	this.classType = classType;
}
public TransactionDetails getTransactionDetails() {
	return transactionDetails;
}
public void setTransactionDetails(TransactionDetails transactionDetails) {
	this.transactionDetails = transactionDetails;
}
}