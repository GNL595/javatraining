package com.eventmanagement.beans;

public class Menu {
		private String nameofItem,itemAvailability;
		private int itemCost;
		
		public Menu(String nameofItem, String itemAvailability, int itemCost) {
			super();
			this.nameofItem = nameofItem;
			this.itemAvailability = itemAvailability;
			this.itemCost = itemCost;
		}
		public String getNameofItem() {
			return nameofItem;
		}
		public void setNameofItem(String nameofItem) {
			this.nameofItem = nameofItem;
		}
		public String getItemAvailability() {
			return itemAvailability;
		}
		public void setItemAvailability(String itemAvailability) {
			this.itemAvailability = itemAvailability;
		}
		public int getItemCost() {
			return itemCost;
		}
		public void setItemCost(int itemCost) {
			this.itemCost = itemCost;
		}
		
}
